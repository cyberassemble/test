import tinydb

conn = tinydb.TinyDB('./storge.json')
Query = tinydb.Query()